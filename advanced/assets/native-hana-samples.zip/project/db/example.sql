insert into FOO_BAR_EXT_TAB1(id, some_text) values (1, 'first');
insert into FOO_BAR_EXT_TAB1(id, some_text) values (2, 'second');
insert into FOO_BAR_EXT_TAB1(id, some_text) values (3, 'third');
insert into FOO_BAR_EXT_TAB1(id, some_text) values (4, 'fourth');
insert into FOO_BAR_EXT_TAB1(id, some_text) values (5, 'fifth');


select * from FOO_BAR_MYSERVICE_TAB1;
select * from FOO_BAR_MYSERVICE_TAB2;
select * from FOO_BAR_MYSERVICE_TAB3;

select * from FOO_BAR_MYSERVICE_VIEW1('vwp 1');
select * from FOO_BAR_MYSERVICE_VIEW2('vwp 2');

select * from FOO_BAR_MYSERVICE_FUNC1;
select * from FOO_BAR_MYSERVICE_FUNC2('func 2');

select * from FOO_BAR_EXT_CV1;
select * from FOO_BAR_EXT_CV1();
select * from FOO_BAR_MYSERVICE_CV1;

select * from FOO_BAR_EXT_CV2(placeholder."$$PARAM$$" => 10);
select * from FOO_BAR_MYSERVICE_CV2(10);

select * from "foo.bar.ext.cv3"(placeholder."$$Param$$" => 10);
select * from FOO_BAR_MYSERVICE_CV3(10);
