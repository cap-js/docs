# Examples of using existing database objects

A CDS project that shows how to integrate existing database objects into a CDS model.

Examples of how to represent in CDS the following existing in the database objects are covered:
  * database tables
  * SQL views without parameters
  * table functions without parameters
  * calculation views without parameters
  * an SQL view with parameters
  * or a table function with parameters
  * or a calculation view with parameters

The two flavours of names - **plain** and **quoted** are shown. More about the topic [here](https://cap.cloud.sap/docs/advanced/hana/) - Using Native SAP HANA Artifacts

## Example index

This table shows the relationship among the CDS artifacts, the DB objects and the files needed for everything to work properly:

| what         | db object         | in file                | mapping object    | in file          | facade entity(data-model.cds) | service entity(service.cds) |
| ---          | ---               | ---                    | ---               | ---              | ---                           | ---                         |
|              |                   | existing_...           | n/a               | mapping_...      | foo.bar.ext....               | foo.bar.MyService....       |
| table        | FOO_BAR_EXT_TAB1  | tab1.hdbtable          | n/a               |                  | Tab1                          | Tab1                        |
| table        | foo.bar::ext.Tab2 | tab2.hdbtable          | FOO_BAR_EXT_TAB2  | tab2.hdbsynonym  | Tab2                          | Tab2                        |
| table        | foo.bar::ext.Tab3 | tab3.hdbtable          | FOO_BAR_EXT_TAB3  | tab3.hdbview     | Tab3                          | Tab3                        |
| view w param | FOO_BAR_EXT_VIEW1 | view1.hdbview          | n/a               |                  | View1                         | View1                       |
| view w param | foo.bar.ext.View2 | view2.hdbview          | FOO_BAR_EXT_VIEW2 | view2.hdbview    | View2                         | View2                       |
| func         | FOO_BAR_EXT_FUNC1 | func1.hdbfunction      | n/a               |                  | Func1                         | Func1                       |
| func w param | FOO_BAR_EXT_FUNC2 | func2.hdbfunction      | n/a               |                  | Func2                         | Func2                       |
| cv           | FOO_BAR_EXT_CV1   | cv1.hdbcalculationview | n/a               |                  | CV1                           | CV1                         |
| cv w param   | FOO_BAR_EXT_CV2   | cv2.hdbcalculationview | n/a               |                  | CV2                           | CV2                         |
| cv w param   | foo.bar.ext.cv3   | cv3.hdbcalculationview | FOO_BAR_EXT_CV3   | cv3.hdbview      | CV3                           | CV3                         |